#ifndef DBCOURSEOFFERING_H
#define DBCOURSEOFFERING_H

namespace Logical_View {
	namespace Design_Model {
		namespace Business_Services {
			namespace CourseCatalogSystem {
				class DBCourseOffering {
				};
			}
		}
	}
}

#endif
