#include "ICourseCatalogSystem.h"

void Logical_View::Design_Model::Business_Services::External_System_Interfaces::ICourseCatalogSystem::getCourseOfferings() {
	// TODO - implement ICourseCatalogSystem::getCourseOfferings
	throw "Not yet implemented";
}

void Logical_View::Design_Model::Business_Services::External_System_Interfaces::ICourseCatalogSystem::initialize() {
	// TODO - implement ICourseCatalogSystem::initialize
	throw "Not yet implemented";
}
