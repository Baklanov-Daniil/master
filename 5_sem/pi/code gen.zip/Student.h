#ifndef STUDENT_H
#define STUDENT_H

namespace Logical_View {
	namespace Design_Model {
		namespace Business_Services {
			namespace University_Artifacts {
				class Student {

				private:
					string address;
					string name;
					int studentID;
					static int nextAvailID;
					date dateOfBirth;

				public:
					void addSchedule(Logical_View::Design_Model::Business_Services::University_Artifacts::Schedule theSchedule);

					Logical_View::Design_Model::Business_Services::University_Artifacts::Schedule getSchedule(Semester forSemester);

					void deleteSchedule(Semester forSemester);

					double getTuition();

					boolean hasPrerequisites(Logical_View::Design_Model::Business_Services::University_Artifacts::CourseOffering forCourseOffering);

				protected:
					boolean passed(Logical_View::Design_Model::Business_Services::University_Artifacts::CourseOffering theCourseOffering);

				public:
					static int getNextAvailID();

					int getStudentID();

					string getName();

					string getAddress();
				};
			}
		}
	}
}

#endif
