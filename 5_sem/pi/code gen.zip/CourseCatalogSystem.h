#ifndef COURSECATALOGSYSTEM_H
#define COURSECATALOGSYSTEM_H

namespace Logical_View {
	namespace Design_Model {
		namespace Business_Services {
			namespace CourseCatalogSystem {
				class CourseCatalogSystem : Logical_View::Design_Model::Business_Services::External_System_Interfaces::ICourseCatalogSystem {
				};
			}
		}
	}
}

#endif
