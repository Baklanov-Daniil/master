#ifndef FULLTIMECLASSIFICATION_H
#define FULLTIMECLASSIFICATION_H

namespace Logical_View {
	namespace Design_Model {
		namespace Business_Services {
			namespace University_Artifacts {
				class FulltimeClassification : Logical_View::Design_Model::Business_Services::University_Artifacts::Student, Logical_View::Design_Model::Business_Services::University_Artifacts::Classification {

				private:
					int gradDate;
				};
			}
		}
	}
}

#endif
