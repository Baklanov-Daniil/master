#ifndef ICOURSECATALOGSYSTEM_H
#define ICOURSECATALOGSYSTEM_H

namespace Logical_View {
	namespace Design_Model {
		namespace Business_Services {
			namespace External_System_Interfaces {
				class ICourseCatalogSystem {


				public:
					void getCourseOfferings();

					void initialize();
				};
			}
		}
	}
}

#endif
