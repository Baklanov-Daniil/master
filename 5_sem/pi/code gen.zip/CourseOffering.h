#ifndef COURSEOFFERING_H
#define COURSEOFFERING_H

namespace Logical_View {
	namespace Design_Model {
		namespace Business_Services {
			namespace University_Artifacts {
				class CourseOffering {

				private:
					Enum days;
					Time endTime;
					String number;
					Time startTime;
				};
			}
		}
	}
}

#endif
