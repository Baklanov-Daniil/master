#ifndef REGISTRATIONCONTROLLER_H
#define REGISTRATIONCONTROLLER_H

namespace Logical_View {
	namespace Design_Model {
		namespace Application {
			namespace Registration {
				class RegistrationController {
				};
			}
		}
	}
}

#endif
