#ifndef SCHEDULEOFFERINGINFO_H
#define SCHEDULEOFFERINGINFO_H

namespace Logical_View {
	namespace Design_Model {
		namespace Business_Services {
			namespace University_Artifacts {
				class ScheduleOfferingInfo {

				private:
					int status;
				};
			}
		}
	}
}

#endif
