#ifndef COURSE_H
#define COURSE_H

namespace Logical_View {
	namespace Design_Model {
		namespace Business_Services {
			namespace University_Artifacts {
				class Course {
				};
			}
		}
	}
}

#endif
