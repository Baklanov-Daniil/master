#ifndef SCHEDULE_H
#define SCHEDULE_H

namespace Logical_View {
	namespace Design_Model {
		namespace Business_Services {
			namespace University_Artifacts {
				class Schedule {

				private:
					int semester;
				};
			}
		}
	}
}

#endif
