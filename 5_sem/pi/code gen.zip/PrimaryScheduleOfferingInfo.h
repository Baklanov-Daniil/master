#ifndef PRIMARYSCHEDULEOFFERINGINFO_H
#define PRIMARYSCHEDULEOFFERINGINFO_H

namespace Logical_View {
	namespace Design_Model {
		namespace Business_Services {
			namespace University_Artifacts {
				class PrimaryScheduleOfferingInfo : Logical_View::Design_Model::Business_Services::University_Artifacts::ScheduleOfferingInfo {

				private:
					int grade;
				};
			}
		}
	}
}

#endif
