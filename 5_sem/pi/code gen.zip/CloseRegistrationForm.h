#ifndef CLOSEREGISTRATIONFORM_H
#define CLOSEREGISTRATIONFORM_H

namespace Logical_View {
	namespace Design_Model {
		namespace Application {
			namespace Registration {
				class CloseRegistrationForm {
				};
			}
		}
	}
}

#endif
