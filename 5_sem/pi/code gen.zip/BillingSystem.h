#ifndef BILLINGSYSTEM_H
#define BILLINGSYSTEM_H

namespace Logical_View {
	namespace Design_Model {
		class BillingSystem {
		};
	}
}

#endif
