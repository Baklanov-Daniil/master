#include "Student.h"

void Logical_View::Design_Model::Business_Services::University_Artifacts::Student::addSchedule(Logical_View::Design_Model::Business_Services::University_Artifacts::Schedule theSchedule) {
	// TODO - implement Student::addSchedule
	throw "Not yet implemented";
}

Logical_View::Design_Model::Business_Services::University_Artifacts::Schedule Logical_View::Design_Model::Business_Services::University_Artifacts::Student::getSchedule(Semester forSemester) {
	// TODO - implement Student::getSchedule
	throw "Not yet implemented";
}

void Logical_View::Design_Model::Business_Services::University_Artifacts::Student::deleteSchedule(Semester forSemester) {
	// TODO - implement Student::deleteSchedule
	throw "Not yet implemented";
}

double Logical_View::Design_Model::Business_Services::University_Artifacts::Student::getTuition() {
	// TODO - implement Student::getTuition
	throw "Not yet implemented";
}

boolean Logical_View::Design_Model::Business_Services::University_Artifacts::Student::hasPrerequisites(Logical_View::Design_Model::Business_Services::University_Artifacts::CourseOffering forCourseOffering) {
	// TODO - implement Student::hasPrerequisites
	throw "Not yet implemented";
}

boolean Logical_View::Design_Model::Business_Services::University_Artifacts::Student::passed(Logical_View::Design_Model::Business_Services::University_Artifacts::CourseOffering theCourseOffering) {
	// TODO - implement Student::passed
	throw "Not yet implemented";
}

static int Logical_View::Design_Model::Business_Services::University_Artifacts::Student::getNextAvailID() {
	return this->nextAvailID;
}

int Logical_View::Design_Model::Business_Services::University_Artifacts::Student::getStudentID() {
	return this->studentID;
}

string Logical_View::Design_Model::Business_Services::University_Artifacts::Student::getName() {
	return this->name;
}

string Logical_View::Design_Model::Business_Services::University_Artifacts::Student::getAddress() {
	return this->address;
}
