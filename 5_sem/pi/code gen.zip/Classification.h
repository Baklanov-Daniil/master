#ifndef CLASSIFICATION_H
#define CLASSIFICATION_H

namespace Logical_View {
	namespace Design_Model {
		namespace Business_Services {
			namespace University_Artifacts {
				class Classification {
				};
			}
		}
	}
}

#endif
