#ifndef PROFESSER_H
#define PROFESSER_H

namespace Logical_View {
	namespace Design_Model {
		namespace Business_Services {
			namespace University_Artifacts {
				class Professer {
				};
			}
		}
	}
}

#endif
