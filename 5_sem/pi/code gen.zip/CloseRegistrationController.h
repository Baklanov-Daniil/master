#ifndef CLOSEREGISTRATIONCONTROLLER_H
#define CLOSEREGISTRATIONCONTROLLER_H

namespace Logical_View {
	namespace Design_Model {
		namespace Application {
			namespace Registration {
				class CloseRegistrationController {
				};
			}
		}
	}
}

#endif
